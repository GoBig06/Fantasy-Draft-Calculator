import os
import sys
import json
import collections

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s
try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class DraftAnalysisEvents(QtCore.QObject):
    def draftAnalysisEventsself(self,msgType,ack):
        self.emit(QtCore.SIGNAL(_fromUtf8("draftAnalysisMessage(PyQt_PyObject)")),(msgType,ack))
        if msgType != None:
            self.emit(QtCore.SIGNAL(_fromUtf8("draftAnalysisMessage_%s(PyQt_PyObject)"%(msgType))),ack)

class DraftAnalysis:
    def __init__(self,numTeams,leagueFormat):
        self.keepGoing = True
        self.numTeams = numTeams
        self.leagueFormat = leagueFormat
        self.numTeams = 10
        self.leagueFormat = 'FULL_PPR'
        self.draftCorrelationCutOff = 0.9
        self.playerArray = []
        self.desiredPlayerDict = collections.defaultdict(dict)
        self.jsonFile = '%s_%s_TEAM_DRAFT_DATA.json'  % (str(self.leagueFormat), str(self.numTeams))
        self.DraftDataDict = collections.defaultdict(dict)
        self.currentDraftDict = {}
        self.currentDraftDict['Ezekiel Elliott'] = 4
        self.currentDraftDict['LeVeon Bell'] = 2
        self.currentDraftDict['David Johnson'] = 1
        self.currentDraftDict['Antonio Brown'] = 3
        self.currentDraftDict['Julio Jones'] = 5
        self.currentDraftDict['Odell Beckham Jr'] = 6
        self.currentDraftDict['LeSean McCoy'] = 7

    def createPlayerArray(self):
        player_list = os.getcwd() + '\\Player_List.txt'
        with open(player_list,'r') as playerList:
            for player in playerList:
                self.playerArray.append(player)

    def calculatePlayerOdd(self):
        self.loadJsonToDict()

    def loadJsonToDict(self):
        with open(self.jsonFile, "r") as json_file:
            for line in json_file:
                self.DraftDataDict = json.loads(line)

    def mockDraftCorrelation(self):
        player_drafted_counter = 0
        self.draftCorrelationArray = []
        #for key in currentDraftDict:
        for draftNumber in self.DraftDataDict:
            for player in self.currentDraftDict:
                if len(self.currentDraftDict) > self.DraftDataDict[draftNumber][player]:
                    player_drafted_counter = player_drafted_counter + 1
            draftCorrelation = player_drafted_counter/len(self.currentDraftDict)
            if draftCorrelation > self.draftCorrelationCutOff:
                self.draftCorrelationArray.append(draftNumber)
            player_drafted_counter = 0

    def playerOdds(self):
        for player in self.desiredPlayerDict:
            for draftNumber in self.draftCorrelationArray:
                if self.desiredPlayerDict[player] < self.DraftDataDict[draftNumber][player]:
                    foo='bar'



    def run(self):
        while self.keepGoing:
            if self.update is True:
                self.mockDraftCorrelation()
                self.playerOdds()

