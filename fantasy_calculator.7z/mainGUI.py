import os
import sys
import time

import DraftAnalysis
import MockDraft

import mainwindow

from PyQt4 import QtCore, QtGui, Qt
from PyQt4.Qt import QWidget

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s
try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

def enableFields(enable=[]):
    '''enable fields in the gui'''
    for field in enable:
        field.setEnabled(True)

def disableFields(disable=[]):
    '''disable fields in the gui'''
    for field in disable:
        field.setEnabled(False)

class FF_MainWindow(mainwindow.Ui_MainWindow):
    def __init__(self):
        self.LeagueType = None
        self.LeagueSize = None
        self.selectedPlayer = None
        self.playerList = []
        self.playerListSearch = []
        self.playerlistDrafted = []
        self.rowPosition = 1
        self.columnPosition = 1
        self.draftCount = 1
        self.DraftAnalysisEvents = DraftAnalysis.DraftAnalysisEvents()
    def setupUi2(self,MainWindow):
        self.MainWindow = MainWindow
        #Set League parameters
        QtCore.QObject.connect(self.comboBoxLeagueType, QtCore.SIGNAL(_fromUtf8("currentIndexChanged(QString)")), self.comboBoxLeagueTypeChanged)
        QtCore.QObject.connect(self.comboBoxNumberOfTeams, QtCore.SIGNAL(_fromUtf8("currentIndexChanged(QString)")), self.comboBoxNumberOfTeamsChanged)
        QtCore.QObject.connect(self.comboBoxDraftPick, QtCore.SIGNAL(_fromUtf8("currentIndexChanged(QString)")), self.comboBoxDraftPickChanged)
        #Load Draft Data
        QtCore.QObject.connect(self.pushButtonLoadFantasyData, QtCore.SIGNAL(_fromUtf8("clicked()")), self.LoadDraftData)
        #Player List
        QtCore.QObject.connect(self.listWidgetPlayerList, QtCore.SIGNAL(_fromUtf8("itemClicked()")), self.listWidgetPlayerListClicked)
        QtCore.QObject.connect(self.lineEditPlayerSearch,  QtCore.SIGNAL(_fromUtf8("textEdited(QString)")),self.startPlayerSearch)
        QtCore.QObject.connect(self.pushButtonDraftPlayer, QtCore.SIGNAL(_fromUtf8("clicked()")), self.draftSelectedPlayer)
        QtCore.QObject.connect(self.pushButtonUndoDraftedPlayer, QtCore.SIGNAL(_fromUtf8("clicked()")), self.undraftSelectedPlayer)
        #Draft Stats
        QtCore.QObject.connect(self.comboBoxCalculateOddsRound, QtCore.SIGNAL(_fromUtf8("currentIndexChanged(QString)")),self.roundToCalculate)
        QtCore.QObject.connect(self.pushButtonCalculateDraftOdds, QtCore.SIGNAL(_fromUtf8("clicked()")),self.calculateDraft)
        #CallBacks to update text browser


    def comboBoxLeagueTypeChanged(self):
        LeagueType = str(self.comboBoxLeagueType.currentText())
        if LeagueType == 'Standard':
            self.LeagueType = 'STANDARD'
        if LeagueType == 'PPR':
            self.LeagueType = 'FULL_PPR'
        if LeagueType == '2 QB':
            self.LeagueType = '2_QB'
        if LeagueType == 'Dynasty':
            self.LeagueType = 'DYNASTY'
        if LeagueType == 'Dynasty':
            self.LeagueType = 'DYNASTY ROOKIE'

    def comboBoxNumberOfTeamsChanged(self):
        LeagueSize = str(self.comboBoxNumberOfTeams.currentText())
        if LeagueSize == '8 Team':
            self.LeagueSize = 8
            self.upDateDraftPick()
        if LeagueSize == '10 Team':
            self.LeagueSize = 10
            self.upDateDraftPick()
        if LeagueSize == '12 Team':
            self.upDateDraftPick()
            self.LeagueSize = 12
            self.upDateDraftPick()
        if LeagueSize == '14 Team':
            self.LeagueSize = 14
            self.upDateDraftPick()

    def comboBoxDraftPickChanged(self):
        foo = 1

    def upDateDraftPick(self):
        self.comboBoxDraftPick.clear()
        for leagueSize in range(8,14,2):
            if leagueSize == self.LeagueSize:
                for pick in range(1,(leagueSize+1),1):
                    var = 'Pick ' + str(pick)
                    self.comboBoxDraftPick.addItem(str(var))

    def LoadDraftData(self):
        disableFields([self.comboBoxLeagueType,self.comboBoxNumberOfTeams,self.comboBoxDraftPick,self.pushButtonLoadFantasyData])
        enableFields([self.pushButtonResetDraftData])
        self.upDateDraftTable()
        self.loadPlayerList(self.playerList)

    ######## Player Drafting CODE ##################
    def loadPlayerList(self,playerList):
        playListFile = os.getcwd() + '\\Player_List.txt'
        self.listWidgetPlayerList.clear()
        with open(playListFile,'r') as file:
            for line in file:
                playerList = line.strip()
        self.updatePlayerList(playerList)
        enableFields([self.lineEditPlayerSearch,self.pushButtonDraftPlayer,self.lineEditPlayerSearch])

    def updatePlayerList(self,playerList):
        for player in playerList:
            self.listWidgetPlayerList.addItem(playerList)

    def startPlayerSearch(self):
        enableFields([self.pushButtonDraftPlayer])
        tempPlayerList = []
        currentText = self.listWidgetPlayerList.currentText()
        #Wait for user to stop typing
        while():
            time.sleep(0.5)
            if currentText == self.listWidgetPlayerList.currentText():
                break
            else:
                currentText = self.listWidgetPlayerList.currentText()
        for player in self.playerList:
            if currentText in player:
                self.playerListSearch.append(player)
        self.upDatePlayerList(self.playerListSearch)

    def listWidgetPlayerListClicked(self):
        self.lineEditPlayerSearch.setText(_fromUtf8(self.listWidgetPlayerList.currentText()))

    def draftSelectedPlayer(self):
        enableFields([self.pushButtonUndoDraftedPlayer])
        self.setTableWithSelectedPlay()

    def undraftSelectedPlayer(self):
        #TO DO
        foo='bar'
    ######## Player Drafting CODE ##################

    ######## DRAFT TABLE CODE ##################
    def upDateDraftTable(self):
        self.tableWidgetDraftTable()
        #Add Rows
        for row in range(1,15):
            self.tableWidgetDraftTable.insertRow(row)
        #Add Columns
        for column in range(1,self.LeagueSize):
            self.tableWidgetDraftTable.insertRow(column)

    def setTableWithSelectedPlay(self):
        self.tableWidgetDraftTable.setItem(self.rowPosition, self.columnPosition, QtGui.QTableWidgetItem(self.selectedPlayer))
        self.draftCount = self.draftCount + 1
        self.updateRowAndColumns()

    def updateRowAndColumns(self):
        #Check to see if we are at a corner
        #If so go to the next round
        if self.draftCount % self.LeagueSize == 0:
            self.rowPosition = self.rowPosition + 1
            #reset columns
            #even reset to league size
            #Odd reset to 1
            if self.rowPosition % 2 == 0:
                self.columnPosition = self.LeagueSize
            else:
                self.columnPosition = 1
        else:
            self.columnPosition = self.columnPosition +1
    ######## DRAFT TABLE CODE ##################

    ######## DRAFT Calculations CODE ##################
    def calculateDraft(self):
        foo = 1
    def roundToCalculate(self):
        foo = 1
    ######## DRAFT Calculations CODE ##################
if __name__ == "__main__":
    app = QtGui.QApplication(sys.argv)
    MainWindow = QtGui.QMainWindow()
    ui = FF_MainWindow()
    ui.setupUi(MainWindow)
    ui.setupUi2(MainWindow)
    MainWindow.show()
    try:
        sys.exit(app.exec_())
    except:
        pass
    #Close threads
    # finally:
    #     if ui.:
